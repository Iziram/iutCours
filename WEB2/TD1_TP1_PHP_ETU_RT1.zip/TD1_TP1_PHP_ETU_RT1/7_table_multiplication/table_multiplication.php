<!DOCTYPE html>
<html lang="fr" >
<head>
<meta charset="utf-8">
<title>EXO Tables Multiplication</title>
</head>
<body>
 
<?php
		  

 ?>
</body></html>