<!DOCTYPE html>
<html lang="fr" >
	<head>
		<meta charset="utf-8">
		<title>WEB2 TD12 EX5 : Formulaire dynamique & BDD ETUDIANTS</title>
	</head>
	<body>
		<h1>WEB2 TD12 EX5 : Formulaire dynamique & BDD ETUDIANTS</h1>   
		
		<?php	
			afficheFormulaireEtudiantParVille();
		?>
		
		<?php
			/* Définition des fonctions */ 
			function afficheFormulaireEtudiantParVille(){
				// CNX BDD + REQUETE pour obtenir les villes correspondantes à des utilisateurs
				
				
			?>
			<form action="" method="post">
				<fieldset> 
					<label for="id_ville">Ville :</label> 
					<select id="id_ville" name="ville" size="1">
						<option value="0">Choisir une ville</option>
						<?php
							// générer la liste des options à partir de $villes
							
						?>
					</select>
					<input type="submit" value="Rechercher Etudiant par Ville"/>
				</fieldset>
			</form>
			<?php
				//var_dump($villes);
			}// fin afficheFormulaireEtudiantParVille
		?>
		
		
		
		
		
		
		
	</body>
</html>