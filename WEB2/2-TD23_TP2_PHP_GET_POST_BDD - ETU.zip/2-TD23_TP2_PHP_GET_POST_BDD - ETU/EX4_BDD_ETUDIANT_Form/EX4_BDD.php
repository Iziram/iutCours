<!DOCTYPE html>
<html lang="fr" >
	<head>
		
		<meta charset="utf-8">
		<title>WEB2 TD12 EX4 : Formulaires & BDD ETUDIANTS</title>
	</head>
	<body>
		<h1>WEB2 TD12 EX4 : Formulaires & BDD ETUDIANTS</h1>   
		
		<?php	
			
			
			
			
			
		?>
		
	</body>
</html>