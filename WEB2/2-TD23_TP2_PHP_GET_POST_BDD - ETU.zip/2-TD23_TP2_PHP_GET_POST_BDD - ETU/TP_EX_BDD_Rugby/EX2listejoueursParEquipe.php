<!DOCTYPE html>
<html lang="fr" >
	<head>
		<meta charset="utf-8">
		<title>EX2 Liste des joueurs Filtre    NOM</title>
		<link href="style.css" rel="stylesheet" type="text/css" />
	</head>
	<body>
		<h1>EX2 Liste des joueurs Filtre    NOM</h1>
		<?php	
			
			
			
			
			
			
		?>
		
	</body>
</html>