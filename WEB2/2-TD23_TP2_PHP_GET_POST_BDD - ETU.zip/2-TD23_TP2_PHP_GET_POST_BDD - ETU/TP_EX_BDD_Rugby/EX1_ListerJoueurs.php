<!DOCTYPE html>
<html lang="fr" >
	<head>
		<meta charset="utf-8">
		<title>EX1   Liste des joueurs             NOM</title>
		<link href="style.css" rel="stylesheet" type="text/css" />
	</head>
	<body>
		<h1>EX1   Liste des joueurs             NOM</h1>
		
		<?php	
			
			
			
			
		?>
	</body>
</html>