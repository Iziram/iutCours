<!DOCTYPE html>
<html lang="fr" >
	<head>
		<meta charset="utf-8">
		<title>EX3   Insertion d'un joueur       NOM</title>
		<link href="style.css" rel="stylesheet" type="text/css" />
	</head>
	<body>
		<h1>EX3   Insertion d'un joueur       NOM</h1>
		<?php
			
			
			
			
		?>
	</body>
</html>



