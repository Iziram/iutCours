<?php
	var_dump($_GET);
	echo "<p>Q1</p>";
	
	
	echo "<p>Q2</p>";
	
	
	echo "<p>Q3</p>";
	
	
?>