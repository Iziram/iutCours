<!DOCTYPE html>
<html lang="fr" >
	<head>
		<meta charset="utf-8">
		<title>WEB2 TD1 EX2 : Formulaires POST</title>
	</head>
	<body>
		
	</body>
</html>