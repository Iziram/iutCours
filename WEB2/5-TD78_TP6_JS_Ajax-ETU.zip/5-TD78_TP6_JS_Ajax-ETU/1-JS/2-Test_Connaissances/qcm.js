// Fonction vérifiant la question 1 : la réponse est 1995
    function verifierQ1(){
      var reponses=document.getElementsByName("annee");
	  var choix;
	  for(var i=0; i < reponses.length; i++){
		if(reponses[i].checked){
			choix=reponses[i].value;
		}
	  }
	  // Vérifier si la case cochée est correcte, si oui, afficher la question 2
	  // sinon afficher un message. Le message doit être stylé.
      
    }
    
    // Fonction vérifiant la bonne réponse à la question 2 : la réponse est 10
    function verifierQ2(){
     
     // On stocke dans une variable 'saisie' la saisie du nombre de jours

     // On incrémente le nombre de tentatives

     // Si le nombre de tentatives est supérieure à 10 ou que la réponse est correcte
     // on affiche un message et on passe à la question 3
     
     
     // sinon on affiche en message le numéro de la tentative, le nombre saisi
     // ainsi que l'indication "C'est plus" ou "C'est moins"
     

     
    }


    // Fonction vérifiant la question 3 : la réponse est vrai
    // Inspirez vous de la fonction verifierQ1()
    function verifierQ3(){
    
    }

    // Fonction cachant les 3 questions ainsi que le message final
    function cacherQuestions(){
    
    }

    // Fonction affichant la question dont le numéro sera passé en paramètre
    function afficherQuestion(){
    
    }
