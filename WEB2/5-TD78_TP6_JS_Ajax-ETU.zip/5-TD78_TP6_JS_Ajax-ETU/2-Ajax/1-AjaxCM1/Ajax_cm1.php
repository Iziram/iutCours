<!DOCTYPE html>
<html lang="fr">

<head>
    <meta charset="utf-8" />
    <script type="text/javascript" src="ajax.js"></script>
    <title> Essai AJAX XMLHTTPRequest </title>
</head>

<body>
    <h1> Essai AJAX XMLHTTPRequest </h1>
    <p id="bonjour">Ce paragraphe s'affiche au chargement initial de la page</p>
    <div id="vide"></div>
    <button onclick="EnvoiRequete()">Lancement requête Ajax</button>
    <p id="etat">On affichera ici l'état d'avancement de la requête AJAX</p>
</body>

</html>