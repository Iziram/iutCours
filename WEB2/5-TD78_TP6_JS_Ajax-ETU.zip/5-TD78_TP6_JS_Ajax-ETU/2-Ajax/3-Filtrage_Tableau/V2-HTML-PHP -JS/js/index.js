function listerVilles(ville){
window.location.assign("index.php?ville="+ville.value);
}