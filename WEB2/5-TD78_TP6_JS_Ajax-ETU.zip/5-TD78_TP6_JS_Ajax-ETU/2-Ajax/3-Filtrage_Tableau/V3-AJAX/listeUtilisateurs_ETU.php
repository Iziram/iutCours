<?php

if (!empty($_POST) && isset($_POST["choix"])){		



}
?>