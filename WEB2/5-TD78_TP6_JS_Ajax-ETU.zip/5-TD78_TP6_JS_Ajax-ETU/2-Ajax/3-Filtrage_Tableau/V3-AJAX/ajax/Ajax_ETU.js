﻿/*****************************************************************/
function listeFiltreUtilisateurs(ville)	{
var req_AJAX = null;// Objet qui sera crée
if (window.XMLHttpRequest) 	{	// Mozilla, Safari
	req_AJAX= new XMLHttpRequest();
	} 
if (req_AJAX) 	{





	} 
else 	{ 	
	alert("EnvoiRequete: pas de XMLHTTP !");	
	}
} // fin fonction listeUtilisateurs()

function TraiteListeFiltreUtilisateurs(requete)	{
	

	
	
	
	
}


