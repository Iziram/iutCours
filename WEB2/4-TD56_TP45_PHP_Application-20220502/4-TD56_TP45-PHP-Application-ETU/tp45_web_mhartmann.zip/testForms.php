<!DOCTYPE html>
<html lang="fr" >
<head>
<meta charset="utf-8">
<link href="style.css" rel="stylesheet" type="text/css" />
<title>Test ListeCompte ETU</title>
</head>
<body>
<header>
<h1>Test ListeCompte ETU</h1>
</header>

<?php


 
?>

</body>
</html>	