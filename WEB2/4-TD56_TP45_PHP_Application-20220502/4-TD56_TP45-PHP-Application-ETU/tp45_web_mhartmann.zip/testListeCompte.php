<!DOCTYPE html>
<html lang="fr" >
<head>
<meta charset="utf-8">
<link href="style.css" rel="stylesheet" type="text/css" />
<title>Test Liste Compte ETU</title>
</head>
<body>
<header>
<h1>Test Liste Compte ETU</h1>
</header>

<?php

include 'fonctions.php';


afficheTableau(listeCompte());


?>
</body>
</html>	
