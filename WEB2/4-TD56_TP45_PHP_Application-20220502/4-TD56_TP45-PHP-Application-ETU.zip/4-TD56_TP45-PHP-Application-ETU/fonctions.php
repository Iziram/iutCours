<?php
	//****************Fonctions utilisées**************************************
	function compteExiste($mail,$pass){
		$retour = false ;
		$madb = new PDO('sqlite:bdd/IUT.sqlite'); 
		$mail= $madb->quote($mail);
		$pass = $madb->quote($pass);
		$requete = "SELECT Email,Pass FROM utilisateurs WHERE Email = ".$mail." AND Pass = ".$pass ;
		//var_dump($requete);echo "<br/>";  	
		$resultat = $madb->query($requete);
		$tableau_assoc = $resultat->fetchAll(PDO::FETCH_ASSOC);
		if (sizeof($tableau_assoc)!=0) $retour = true;	
		return $retour;
	}
	//********************************************************************************
	function isAdmin($mail){
		$retour = false ;
		// A faire
		
		
		
		
		return $retour;		
	}
	//********************************************************************************
	function listeCompte()	{ // A faire
		
		$retour = false ;	
		
		
		return $retour;
	}		
	//*******************************************************************************************
	function afficheTableau($tab){
		echo '<table>';	
		echo '<tr>';// les entetes des colonnes qu'on lit dans le premier tableau par exemple
		foreach($tab[0] as $colonne=>$valeur){		echo "<th>$colonne</th>";		}
		echo "</tr>\n";
		// le corps de la table
		foreach($tab as $ligne){
			echo '<tr>';
			foreach($ligne as $cellule)		{		echo "<td>$cellule</td>";		}
			echo "</tr>\n";
		}
		echo '</table>';
	}
	//*******************************************************************************************
	function listeUtilisateurParVille($insee){
		$retour = false ;
		
		
		
		
		return $retour;
	}
	//*******************************************************************************************
	function ajoutUtilisateur($mail,$pass,$rue,$insee,$status){
		/* on récupère directement le code de la ville qui a été transmis dans l'attribut value de la balise <option> du formulaire
		Il n'est donc pas nécessaire de rechercher le code INSEE de la ville*/
		$retour=0;
		$madb = new PDO('sqlite:bdd/IUT.sqlite'); 	
		// filtrer les paramètres	
		
		
		
		
		
		
		
		return $retour;
	}
	//*******************************************************************************************
	function supprimerUtilisateur($mail){
		$retour=0;
		$madb = new PDO('sqlite:bdd/IUT.sqlite'); 
		// filtrer le paramètre	
		
		
		
		
		
		return $retour;
	}
	//*******************************************************************************************
	function modifierUtilisateur($mail,$pass,$rue,$insee,$status){
		$retour=0;
		$madb = new PDO('sqlite:bdd/IUT.sqlite'); 
		// filtrer les paramètres	
		
		
		
		
		
		
		
		
		return $retour;
	}
	//*******************************************************************************************
	//Nom : redirect()
	//Role : Permet une redirection en javascript
	//Parametre : URL de redirection et Délais avant la redirection
	//Retour : Aucun
	//*******************
	function redirect($url,$tps)
	{
		$temps = $tps * 1000;
		
		echo "<script type=\"text/javascript\">\n"
		. "<!--\n"
		. "\n"
		. "function redirect() {\n"
		. "window.location='" . $url . "'\n"
		. "}\n"
		. "setTimeout('redirect()','" . $temps ."');\n"
		. "\n"
		. "// -->\n"
		. "</script>\n";
		
	}
	
?>
