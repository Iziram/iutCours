<?php session_start();?>
<?php 
	include 'fonctions.php';
	include 'formulaires.php';
?>
<!DOCTYPE html>
<html lang="fr" >
	<head>
		<meta charset="utf-8">
		<link href="style.css" rel="stylesheet" type="text/css" />
		<title>WEB2 TD56 TP45 PHP Une Application BDD BDD NOM_ETU 2021-2022</title>
	</head>
	<body>
		<header>
			<h1>WEB2 TD56 TP45 PHP Une Application BDD NOM_ETU 2021-2022</h1>
		</header>
		<nav>
			<?php
				
				
				// affichage du formulaire de connexion ou le menu avec le nom de la personne
				
				
				
				
				// test de la connexion
				
				
				// Destruction de la session 
				
				
				
				
			?>
		</nav>
		<article>
			
			<?php
				// Affichage du message accueil en fonction de la connexion
				echo '<h1>Vous êtes déconnectés</h1>';
				
				
				// traitement de la zone centrale de la page en fonction des liens GET du menu s'il y a une session
				if (!empty($_SESSION) && !empty($_GET) && isset($_GET["action"]) ){
					switch($_GET["action"])
					{
						case "liste_utilisateur":	echo '<h1>Liste des utilisateurs</h1>';
						break;
						case "liste_utilisateur_ville":	echo '<h1>Lister les utilisateurs par villle</h1>';
						break;
					}
				}
				// traitement du premier formulaire interne de recherche par ville	
				
				
				
			?>
		</article>
		<footer>
			<p>Pied de la page <?php echo $_SERVER['PHP_SELF']; ?></p>
			<a href="javascript:history.back()">Retour à la page précédente</a>
		</footer>
	</body>
</html>


