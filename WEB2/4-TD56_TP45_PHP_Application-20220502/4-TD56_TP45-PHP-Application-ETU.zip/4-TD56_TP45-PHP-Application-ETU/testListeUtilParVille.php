<!DOCTYPE html>
<html lang="fr" >
<head>
<meta charset="utf-8">
<link href="style.css" rel="stylesheet" type="text/css" />
<title>Test testListeUtilisateurParVille ETU</title>
</head>
<body>
<header>
<h1>Test testListeUtilisateurParVille ETU</h1>
</header>

<?php

?>
</body>
</html>	
