<!DOCTYPE html>
<html lang="fr" >
	<head>
		<meta charset="utf-8">
		<title>TD3 Sessions</title>
	</head>
	<body>
		
		
		<?php // si absence de session on affiche formulaire
			
		?>
		
		<form id="conn" method="post" action="">
			<p><label for="login">Login :</label><input type="text" id="login" name="login" /></p>
			<p><label for="pass">Mot de Passe :</label><input type="password" id="pass" name="pass" /></p>
			<p><input type="submit" id="submit" name="submit" value="Connexion" /></p>
		</form>
		
		
		
		<?php	// traitement demande de connexion
			if (!empty($_POST) && isset($_POST['login']) && isset($_POST['pass']))	{		
				if ( utilisateurExiste($_POST["login"],$_POST["pass"]) )		{
					
					// si authentification correcte, on ouvre une session
					
					// si admin => session prof
					
					// sinon session etudiant
					
					// Affichage message
					
					/*	<h1>Accueil depuis la page initiale</h1>
						<a href="page_session.php">Lien vers la section membre</a>		
					<p><a href="frm_cnx_sessions.php?action=logout">Se déconnecter</a></p> */
					
				}
			}
		?>
		
		<?php
			// traitement de la fermeture de la session
			
			
			
			
			
			//****************************************************************************************   
			function utilisateurExiste($login,$pass){ 
				try {
					$retour = false;
					$madb = new PDO('sqlite:bdd/IUT.sqlite');			
					$requete = "SELECT * FROM etudiants WHERE mail = '".$login."' AND mdp = '".$pass."'";
					//var_dump($requete);
					$resultat = $madb->query($requete);
					$tableau_assoc = $resultat->fetchAll(PDO::FETCH_ASSOC);
					//var_dump($tableau_assoc );	
					if (sizeof($tableau_assoc)!=0) {	// s'il y a une réponse	=> utilisateur éxiste
						$retour = true;
					}// fin if
				}// fin try
				catch (Exception $e) {		
					echo "Erreur BDD" . $e->getMessage();		
				}	// fin catch	
				return $retour;
			}		
		?>
		
		
		</body>
		</html>		