<!DOCTYPE html>
<html lang="fr" >
	<head>
		<meta charset="utf-8">
		<title>TD3 Sessions</title>
	</head>
	<body>
		
		
		<h1>Bienvenue sur la page accueil des membres</h1>	
		
		<p> Bonjour  Vous êtes </p>			
		
		<p><a href="frm_cnx_sessions.php?action=logout">Se déconnecter et retourner à la page accueil</a></p>
		
		<p><a href="frm_cnx_sessions.php">Vous êtes déconnecté, cliquer pour retourner à la page accueil</a></p>
		
		
		
		
		<body>
		</html>		