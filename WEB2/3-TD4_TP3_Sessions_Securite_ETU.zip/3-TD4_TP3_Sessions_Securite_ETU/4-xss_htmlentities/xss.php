<?php
	if (isset($_GET["var"])){
		$var=$_GET["var"];
		//echo "var : ".htmlentities($var);
		echo "var : ".$var;
	}
?>