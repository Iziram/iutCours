<!DOCTYPE html>
<html lang="fr" >
<head>
<meta charset="utf-8">

<link href="style.css" rel="stylesheet" type="text/css" />
<title>Module WEB2 TD8: Ajax</title>
<script src="ajax/Ajax_ETU.js"></script>
</head>
<body>
<header>
<h1>Module WEB2 TD8: Ajax</h1>
<h1>Lister les utilisateurs par villle en AJAX</h1>
</header>

<?php
include('formulaires_ETU.php');
afficheFormulaireEtudiantParVilleAJAX();

?>
<div id="tableau"></div>
</body>
</html>


