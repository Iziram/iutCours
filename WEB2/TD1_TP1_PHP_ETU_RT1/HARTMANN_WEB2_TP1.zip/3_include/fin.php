<footer>
<p>Pied de Page</p>
</footer>
</body>
</html> 