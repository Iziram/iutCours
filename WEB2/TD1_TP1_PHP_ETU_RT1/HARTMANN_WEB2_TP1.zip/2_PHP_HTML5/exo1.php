<!DOCTYPE html>
<html lang="fr">
    <head>
        <meta charset="utf-8">
        <title>TD 1</title>
    </head>
    <body>
        <p>
            <?php
                $nom = "Matthias";
                echo $nom;
            ?>
        </p>
    </body>
</html>
