<?php

    include("fonctions.php");

    EnteteTitrePage("Exo 3");

    $nom = "Matthias";
    echo "<article>$nom</article>";


    PiedDePage();

?>