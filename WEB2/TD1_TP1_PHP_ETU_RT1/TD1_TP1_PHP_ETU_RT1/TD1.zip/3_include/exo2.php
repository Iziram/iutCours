<?php include("entete.php");?>
<article>
    <?php
        $nom = "Matthias";
        echo $nom;
    ?>
</article>
<?php include("fin.php");?>
