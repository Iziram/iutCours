<!DOCTYPE html>
<html lang="fr" >
<head>
<meta charset="utf-8">
<title>ETU EXO2 Include</title>
<link href="style.css" rel="stylesheet" type="text/css" />
</head>
<body>
<header>
<h1> ETU EXO2 Include </h1>
</header>
